import json




with open("BarcodeInfo.json", 'r') as f:
    item_json = json.load(f)
    
for x in item_json['foods']:
    for y in x['foodNutrients']:
        if 'nutrientName' in y.keys():
            if 'Protein' in y['nutrientName']:
                print(y['nutrientName'] + ': ' + str(y['value']) + y['unitName'])
            if 'Carbohydrate, by difference' in y['nutrientName']:
                print('Carbohydrates' + ': ' + str(y['value']) + y['unitName'])
            if 'Total lipid (fat)'in y['nutrientName']:
                print('Fat' + ': ' + str(y['value']) + y['unitName'])
                
    
        
    

    